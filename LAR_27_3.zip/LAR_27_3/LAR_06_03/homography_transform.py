# https://www.learnopencv.com/homography-examples-using-opencv-python-c/

import numpy as np
import cv2 as cv

#returns transformed image which approximates top down view
def homography_top_down(image):
    image_transformed = np.copy(image) # Create copy of image
    #map_points_source = np.array([[190.0,475.0], [280.0,335.0], [440.0,335.0],[530.0,475.0]]) # Points to map from source
    #map_points_transformed = np.array([[190.0,475.0],[190.0,150.0],[530.0,150.0],[530.0,475.0]]) # Points to map to in transformed #335<>150
    map_points_source = np.array(
        [[241.0, 433.0], [439.0, 430.0], [407.0, 330.0], [270.0, 330.0]])  # Points to map from source
    map_points_transformed = np.array( [[241.0, 433.0], [439.0, 430.0], [439.0, 150.0], [241.0, 150.0]])  # Points to map to in transformed #335<>150
    H,mask=cv.findHomography(map_points_source, map_points_transformed) # Find homography from source points to transformed
    return cv.warpPerspective(image_transformed, H, (image_transformed.shape[1],image_transformed.shape[0]))
