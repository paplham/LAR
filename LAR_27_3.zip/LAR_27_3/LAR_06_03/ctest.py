#!/usr/bin/env python

from turtlebot import Turtlebot, detector
import numpy as np
import cv2
import image_processing as ip
import homography_transform as ht

WINDOW = 'markers'

def main():

    turtle = Turtlebot(rgb=True)
    cv2.namedWindow(WINDOW)

    while not turtle.is_shutting_down():
        # get point cloud
        image = turtle.get_rgb_image()

        # wait for image to be ready
        if image is None:
            continue
        else:
            image_topdown=ht.homography_top_down(image)
            edge_image=ip.canny_filter(image_topdown)#find edges
            masked_image=ip.masking(edge_image,ip.mask_region(edge_image)) #mask upper part of picture
            line_image=np.copy(image)
            lines=ip.hough_lines(masked_image) #hough transform
            line_image=ip.show_lines(line_image, lines)



        # show image
        cv2.imshow(WINDOW, image)
        cv2.waitKey(1)

if __name__ == "__main__":
    main()
