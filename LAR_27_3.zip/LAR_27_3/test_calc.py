int_turn_mean_radius = 0.29 #in meters
int_set_linear_velocity = 0.5 #in m/s
int_set_angle = 3.14 #in rad

int_distance = 3.14*int_turn_mean_radius #in m, half-turn SPATIUM
int_time_required = int_distance/int_set_linear_velocity #in s
int_angular_velocity = int_set_angle/int_time_required #in rad/s

print(int_distance)
print(int_time_required)
print(int_angular_velocity)
