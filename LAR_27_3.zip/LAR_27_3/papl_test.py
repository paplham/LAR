def line_to_angle_and_weight(line):
    x1,y1,x2,y2=line.reshape(4)
    dy=(1.0*y2-1.0*y1)
    dx=(1.0*x2-1.0*x1)
    radians=math.atan2(-dy,dx)
    radians %=2*math.pi
    degrees=-math.degrees(radians)
    if degrees<=-180:
        degrees+=180
    degrees+=90
    length=np.sqrt(dx*dx+dy*dx)
    return degrees, length

def weighted_angle_and_uncertainty(lines):
    if lines!=None:
        degrees_total=0
        length_total=0
        line_count=len(lines[0])
        for line in lines[0]:
            degrees, length=line_to_angle_and_weight(line)
            length_total+=squared_length
            degrees_total+=degrees*length
        weighted_degrees=degrees_total/(length_total*line_count)

        total_weighted_degrees_error=0
        for line in lines[0]:
            degrees, length=line_to_angle_and_weight(line)
            total_weighted_degrees_error+=abs(degrees-weighted_degrees)
        return weighted_degrees, total_weighted_degrees_error

def generate_turn(queue,r=0.29,h=-0.29,k=0):
    '''
    1) go to the turn
    2) reset odometry
    3) precompute the trajectory
    4) move accordingly
    5) (generate points and push them to the goal)
    '''
    #precompute the points in the circle
    #create a queue of x,y positions
    while theta<=270:
        x = h + r*cos(theta)
        y = k + r*sin(theta)
        queue.append((x,y))
        theta+=1
    return queue

def odometry():
    x,y,radians=get_odometry()
    degrees=math.degrees(radians)
    return x,y,degrees

def basic_turn(queue, linear_vel=0.2, angular_vel=1):
    reset_odometry() #Resets the odometry to [0,0,0] i.e. sets new starting position.
    #get odometry
    angle=0
    while len(queue)!=0:
        tar_x, tar_y=queue.popleft()
        x,y,degrees=odometry()
        while(degrees!=angle)
            x,y,degrees=odometry()
            x_diff=x-tar_x
            y_diff=y-tar_y
            #get angle between the two points
            angle=np.arctan(x_diff/y_diff)
            turtle.cmd_velocity(linear=linear_vel, angular=0)
        #
        # target - 0.01 < y < target + 0.01
        while not (tar_x-0.01<x) and not (x<tar_x+0.01) and not (tar_y-0.01<y) and not (y<tar_y+0.01):
            turtle.cmd_velocity(linear=0, angular=angular_vel)
    return
