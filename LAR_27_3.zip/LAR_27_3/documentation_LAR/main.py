import cv2 as cv
import numpy as np
import image_processing as ip
##import matplotlib.pyplot as plt

def homography_top_down(im_src, im_dst):
    pts_src = np.array([[480., 200.], [350., 270.],[480., 550.],[350., 470.]])
    pts_dst = np.array([[480., 200.],[100., 200.],[480., 550.],[100., 400.]])
    h, status = cv.findHomography(pts_src, pts_dst)
    
    im_out = cv.warpPerspective(im_src, h, (im_dst.shape[1],im_dst.shape[0]))
    return im_out

image = cv.imread('Figure_1.png') #load image using cv
image_topdown=np.copy(image)
print(image_topdown)
image_topdown=homography_top_down(image,image_topdown)
edge_image=ip.canny_filter(image_topdown)#find edges
masked_image=ip.masking(edge_image,ip.mask_region(edge_image)) #mask upper part of picture
line_image=np.copy(image)
lines=ip.hough_lines(masked_image) #hough transform
line_image=ip.show_lines(line_image, lines) #draw lines into empty picture

print(lines)

'''
# display all the steps
fig=plt.figure(figsize=(8, 8))
fig.add_subplot(2,2, 1)
plt.imshow(image)
fig.add_subplot(2,2, 2)
plt.imshow(edge_image)
fig.add_subplot(2,2, 3)
plt.imshow(masked_image)
fig.add_subplot(2,2, 4)
plt.imshow(line_image)
plt.show()

fig2=plt.figure(figsize=(8,8))
human_image=cv.addWeighted(line_image, 0.9,image_topdown,1,1)
plt.imshow(human_image)
plt.show()
'''


