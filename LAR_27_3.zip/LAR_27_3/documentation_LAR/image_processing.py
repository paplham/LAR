import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt


###
#SETTINGS
#gauss
gauss_kernel_width,gauss_kernel_height=5,5 #Gaussian blur kernel sizes
#canny
canny_low_threshhold, canny_high_threshhold=100,200 #Canny filter thresholds
#mask
region_of_interest_height=340
region_of_interest_triangle_height=40
#hough
hough_minLineLength=10
hough_maxLineGap=30
hough_threshold=100
rho_resolution=3
theta_resolution=np.pi/180
#SETTINGS END
###


#returns edge detection of copy of image
def canny_filter(image):
    gs_image=np.copy(image) #create a copy
    gs_image=cv.cvtColor(gs_image, cv.COLOR_RGB2GRAY) #grayscale conversion
    #GaussianBlur(input array, (kernel width, kernel height), sigma x, sigma y)
    #if sigma is not given for y, sigma x is used, if sigma is 0 sigma is
    #calculated from kernel size automatically
    blur_image=cv.GaussianBlur(gs_image, (gauss_kernel_width,gauss_kernel_height), 0) #Gaussian blur to remove noise
    #Canny(image, low threshhold, high threshold)
    #documentation recommends thresholds to be 1:2
    edge_image=cv.Canny(blur_image, canny_low_threshhold, canny_high_threshhold) #find edges
    return edge_image

#returns masking polygon to hide unnecessary pixels
def mask_region(image):
    region=np.zeros_like(image)
    w=region.shape[1] #width
    h=region.shape[0] #height
    #create three triangles, constructing one pentagon
    region_definition=np.array([[(w,h),(0,h),(0,region_of_interest_height)],[(0,region_of_interest_height),(w,region_of_interest_height),(w,h)],[(w,region_of_interest_height),(0,region_of_interest_height),(w//2,region_of_interest_height-region_of_interest_triangle_height)]])
    #fill in desired region with white
    cv.fillPoly(region,region_definition, 255)
    return region

#returns AND of image and mask
def masking(image,mask):
    return image & mask

#returns image with highlighted lines, NOT appropriate for vehicle control, appropriate for human sight
def show_lines(image,lines):
    line_image=np.zeros_like(image)
    if lines is not None:
        for line in lines:
            x1,y1,x2,y2=line.reshape(4)
            cv.line(line_image,(x1,y1),(x2,y2),(0,255,0),3)
    return line_image

#returns array of 4-elements arrays (x1,y1,x2,y2) describing two points to be connected
def hough_lines(image):
    #HoughLinesP(image, rho, theta, threshold[, lines[, minLineLength[, maxLineGap]]])
    #rho - distance resolution of rho in accumulator
    #theta - angle resolution of theta in accumulator in radians
    #threshold - Minimum number of votes to make line valid
    #probabilistic Hough transform
    return cv.HoughLinesP(image,rho_resolution, theta_resolution, hough_threshold, minLineLength=hough_minLineLength, maxLineGap=hough_maxLineGap)
