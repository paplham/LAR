from turtlebot import Turtlebot, Rate, get_time

turtle = Turtlebot()
rate = Rate(10)

int_turn_mean_radius = 0.29 #in meters
int_set_linear_velocity = 0.5 #in m/s
int_set_angle = 3.14 #in rad

int_distance = 3.14*int_turn_mean_radius #in m, half-turn SPATIUM
int_time_required = int_distance/int_set_linear_velocity #in s
int_angular_velocity = int_set_angle/int_time_required #in rad/s



t = get_time()

while get_time() - t < int_time_required:
    turtle.cmd_velocity(linear=int_set_linear_velocity, angular = int_angular_velocity)
    rate.sleep()
